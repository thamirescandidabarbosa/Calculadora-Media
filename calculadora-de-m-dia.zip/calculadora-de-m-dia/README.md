# Calculadora de Média

A Pen created on CodePen.io. Original URL: [https://codepen.io/thamirescandidabarbosa/pen/LYmGpmo](https://codepen.io/thamirescandidabarbosa/pen/LYmGpmo).

